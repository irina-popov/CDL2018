# -*- coding: utf-8 -*-
"""
Created on Sat Mar 10 13:36:58 2018

@author: User
"""


import numpy as np
from math import fmod

class Processor():
    nextIdNum=0;
    def __init__(self):
        self.idNum = Processor.nextIdNum
        self.Registers = np.int32([0]*32)
        self.Registers[0]= self.idNum
        Processor.nextIdNum+=1
        self.toSend=[]
        self.active=True
        self.waiting=False
        self.currentLine=0
        
    def __str__(self):
        s=""
        for i in self.Registers:
            if i!=0:
                s+=(str(i)+" ")
        return s
    
    def sett(self, index, val):
        self.Registers[index] = val

        
    def add(self, index, val):
        self.Registers[index] += val

    
    def mul(self, index, val):
        self.Registers[index] *= val

        
    def mod(self, index, val):
        self.Registers[index] = fmod(self.Registers[index],val)

        
    def snd(self, val):
        self.toSend.append(val)

        
    def rcv(self,other, index):
        if  len(other.toSend)>0:
            item = other.toSend.pop(0)
            self.Registers[index] = item
            self.waiting = False
        else:
            self.waiting = True
            
    def jgz(self, val, step):
        if val>0:
            self.currentLine+=step-1


            
    def runLine(self, other, Instructions):
        l = self.currentLine
        if not self.waiting:            
            if Instructions[l][0]=="set":
                index = int(Instructions[l][1][1:])
                if Instructions[l][2][0]=='R':
                    val = self.Registers[int(Instructions[l][2][1:])]
                else:
                    val =  int(Instructions[l][2])                
                Processor.sett(self, index, val)
            if Instructions[l][0]=="mul":
                index = int(Instructions[l][1][1:])
                if Instructions[l][2][0]=='R':
                    val = self.Registers[int(Instructions[l][2][1:])]
                else:
                    val =  int(Instructions[l][2])                
                Processor.mul(self, index, val)
            if Instructions[l][0]=="jgz":
                if Instructions[l][1][0]=='R':
                    val = self.Registers[int(Instructions[l][1][1:])]
                else:
                    val =  int(Instructions[l][1]) 
                if Instructions[l][2][0]=='R':
                    step = self.Registers[int(Instructions[l][2][1:])]
                else:
                    step = int(Instructions[l][2])
                Processor.jgz(self,val,step)  
            if Instructions[l][0]=="add":
                index = int(Instructions[l][1][1:])
                if Instructions[l][2][0]=='R':
                    val = self.Registers[int(Instructions[l][2][1:])]
                else:
                    val =  int(Instructions[l][2])                
                Processor.add(self, index, val)
            if Instructions[l][0]=="mod":
                index = int(Instructions[l][1][1:])
                if Instructions[l][2][0]=='R':
                    val = self.Registers[int(Instructions[l][2][1:])]
                else:
                    val =  int(Instructions[l][2])                
                Processor.mod(self, index, val)
            if Instructions[l][0]=="snd":
                if Instructions[l][1][0]=='R':
                    val = self.Registers[int(Instructions[l][1][1:])]
                else:
                    val =  int(Instructions[l][1]) 
                Processor.snd(self,val)
            if Instructions[l][0]=="rcv":
                index = int(Instructions[l][1][1:])
                Processor.rcv(self,other, index)              
            if not self.waiting:
                self.currentLine+=1
            if self.currentLine>=len(Instructions) or self.currentLine<0:
                self.active=False
        else:
            index = int(Instructions[l][1][1:])
            Processor.rcv(self,other, index)
            if not self.waiting:
                self.currentLine+=1
            
def checkDone(procList):
     #if processors are all inactive or waiting, the execution is done
     done = True
     for i in range(len(procList)):
         if procList[i].active:
             if not procList[i].waiting:
                 done=False
                 break
     return done

         
 
#Function that runs the code for all processors in paralel, line by line:
def runCode(procList, Instructions):
    all_done = False
    while not all_done:
        for i in range(len(procList)):
            if procList[i].active:
#                print("Processor ", i, " current line and state:" )
#                print(Instructions[procList[i].currentLine])
                procList[i].runLine(procList[(N+i-1)%N], Instructions)
#                print(procList[i].__str__())
        all_done=checkDone(procList)

            
if __name__=="__main__":
    file = open('code.in', 'r')
    N= int(file.readline().rstrip())
    #Remember the instructions on each line in a list
    Instructions =[]
    for line in file: 
        Instructions.append(line.split())    
    file.close()

    procList = []    
    for i in range(N):
        p = Processor()
        procList.append(p)        
    runCode(procList, Instructions)
    file = open('code.out', 'w')
    for i in range(N):
        file.write(procList[i].__str__()+"\n")
    file.close()